from modules import *

# make color for logs
def error_color(string: str):
    return colorama.Fore.RED + str(string) + colorama.Style.RESET_ALL
def success_color(string: str):
    return colorama.Fore.GREEN + str(string) + colorama.Style.RESET_ALL
def system_color(string: str):
    return colorama.Fore.YELLOW + str(string) + colorama.Style.RESET_ALL
def wait_color(string: str):
    return colorama.Fore.BLUE + str(string) + colorama.Style.RESET_ALL
def purple_color(string: str):
    return colorama.Fore.MAGENTA + str(string) + colorama.Style.RESET_ALL

def oneTimesRndDo(true_prob=1, false_prob=2):
    return random.choice(
            [False for _ in range(false_prob)] + [True for _ in range(true_prob)]
        )

def do_desicion(true_prob=2, false_prob=4):
    while True:
        machine_choice_do = random.choice(
            [False for _ in range(false_prob)] + [True for _ in range(true_prob)]
        )
        if machine_choice_do:
            print(success_color("[#] Máy đã chọn hành động!"))
            return None
        
        print(purple_color("[*] Máy vẫn chưa chọn hành động... 2s"))
        time.sleep(2)

if __name__ == "__main__":
    print(do_desicion())