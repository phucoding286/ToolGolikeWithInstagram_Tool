from modules import *

# make color for logs
def error_color(string: str):
    return colorama.Fore.RED + str(string) + colorama.Style.RESET_ALL
def success_color(string: str):
    return colorama.Fore.GREEN + str(string) + colorama.Style.RESET_ALL
def system_color(string: str):
    return colorama.Fore.YELLOW + str(string) + colorama.Style.RESET_ALL
def wait_color(string: str):
    return colorama.Fore.BLUE + str(string) + colorama.Style.RESET_ALL
def purple_color(string: str):
    return colorama.Fore.MAGENTA + str(string) + colorama.Style.RESET_ALL

def storage_block_account(username, path_block="./blocked_account.json"):
    try:
        if not os.path.exists(path_block):
            with open(path_block, "w") as file:
                json.dump({username: 0}, file)
        else:
            with open(path_block, "r") as file:
                blocked_accounts = json.load(file)
            if username in blocked_accounts:
                blocked_accounts[username] += 1
                print(system_color(f"[*] đã tăng thành công điểm gỡ bỏ hạn chế của -> {username}"))
            else:
                blocked_accounts[username] = 0
                print(system_color(f"[*] đã gán thành công điểm gỡ bỏ hạn chế cho -> {username}"))
            with open(path_block, "w") as file:
                json.dump(blocked_accounts, file)
        return {"success": f"đã lưu thành công account -> {username} vào danh sách hạn chế"}
    except Exception as e:
        print(e)
        return {"error": "đã có lỗi khi lưu account vào danh sách hạn chế"}
    

def check_and_freedom_for_blocked_account(username, max_times_for_block_account, path_block="./blocked_account.json"):
    try:
        if not os.path.exists(path_block):
            return {"success": "chưa có account nào bị block để check"}
        else:
            with open(path_block, "r") as file:
                blocked_accounts = json.load(file)
            if username in blocked_accounts:
                if blocked_accounts[username] > max_times_for_block_account:
                    blocked_accounts.pop(username)
                    with open(path_block, "w") as file:
                        json.dump(blocked_accounts, file)
                        return {"success": f"đã gỡ hạn chế cho -> {username}"}
                else:
                    blocked_accounts[username] += 1
                    with open(path_block, "w") as file:
                        json.dump(blocked_accounts, file)
                    return {"blocking": f"tài khoản {username} vẫn còn trong phạm vi hạn chế"}
            else:
                return {"success": f"tài khoản {username} không có trong danh sách hạn chế"}
    except:
        return {"error": "có lỗi khi check và gỡ hạn chế cho accounts"}
    
def check_account_only(username, path_block="./blocked_account.json", max_times_for_freedom=100):
    try:
        if not os.path.exists(path_block):
            return {"success": "chưa có account nào bị block để check"}
        else:
            with open(path_block, "r") as file:
                blocked_accounts = json.load(file)
            if username in blocked_accounts:
                if blocked_accounts[username] > max_times_for_freedom:
                    return {"success": f"tài khoản {username} không có trong danh sách hạn chế"}
                else:
                    return {"blocking": f"tài khoản {username} vẫn còn trong phạm vi hạn chế"}
            else:
                return {"success": f"tài khoản {username} không có trong danh sách hạn chế"}
    except Exception as e:
        return {"error": "có lỗi khi check và gỡ hạn chế cho accounts"}
    
if __name__ == "__main__":
    storage_block_account("nguyentram1_")