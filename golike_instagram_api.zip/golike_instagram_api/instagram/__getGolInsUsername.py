from modules import *

# get golike username instagram and account id
def get_golike_instagram_usernames():
    # print and storage IDs and Nicknames
    print()
    print(system_color("[#] các ID instagram trên golike của bạn ↓"))

    IDs = []
    nicknames = []

    nickname_id_result = check_instagram_account_id()
    maxlen = max([len(nickname[1]) for nickname in nickname_id_result]) + 25
    print(system_color(" -" + ((maxlen-1) * "-") ))
    
    for nickname_id in nickname_id_result:
        nickname_id_z = f"| id -> {nickname_id[0]}"
        nickname_id_o = f"| instagram username -> {nickname_id[1]}"
        for _ in range(len(nickname_id_z), maxlen):
            nickname_id_z += " "
        for _ in range(len(nickname_id_o), maxlen):
            nickname_id_o += " "
        nickname_id_z += "|"
        nickname_id_o += "|"
        print(success_color(nickname_id_z))
        print(success_color(nickname_id_o))
        print(system_color(" -" + ((maxlen-1) * "-") ))

        IDs.append(nickname_id[0])
        nicknames.append(nickname_id[1])
    return IDs, nicknames