from modules import *
from __tempBlockDect import (
    check_and_freedom_for_blocked_account,
    storage_block_account
)
from __simuInsRqs import send_random_fake_requests
from __randomDo import do_desicion

# run automation get job and follow instagram and golike
def auto0m(
        instagram_golike_id_input,
        cookies_inp,
        wait_time,
        current_account,
        proxy: bool = True,
        max_times: int = 20,
        maxcount=5,
        sendtimes=5,
        fake_rqs_waitime=2,
        max_times_for_block_account=10
    ):
    
    if os.path.exists("./error_accounts.txt"):
        with open("error_accounts.txt", "r", encoding="utf8") as file:
            error_accounts = file.read().splitlines()
        if str(error_accounts) == "[]":
            print(success_color("[*] Không phát hiện account bị lỗi nào"))
        else:
            print(error_color("[!] các account bị lỗi:"))
            for i in range(len(error_accounts)):
                print(error_color(f"[{i}] {error_accounts[i]}"))
    else:
        with open("error_accounts.txt", "a", encoding="utf8") as file:
            pass

    for _ in range(max_times):
        # print current work instagram account
        print(system_color(f"[0] account đang làm việc hiện tại là -> {current_account}"))
        
        # kiểm tra và gỡ hạn chế nếu đủ điều kiện
        o = check_and_freedom_for_blocked_account(current_account, max_times_for_block_account)
        if "success" in o:
            print(success_color(f"[*] {o['success']}"))
        elif "blocking" in o:
            print(error_color(f"[!] {o['blocking']}"))
            waiting_ui((sendtimes*fake_rqs_waitime)+wait_time, f"-> vui lòng chờ đợi {(sendtimes*fake_rqs_waitime)+wait_time}s")
            do_desicion()
            return {"error": o['blocking']}
        else:
            print(error_color(f"[!] {o['error']}"))

        # send fake requests for simulator real browser
        send_random_fake_requests(current_account, cookies_inp, sendtimes, fake_rqs_waitime)
        
        # trying again error when get job
        r_get_jobs = None
        count = 1
        err = False
        while count < maxcount:
            r_get_jobs = get_jobs(instagram_golike_id_input) # get job from golike
            # if error will return this function
            if "error" in r_get_jobs:
                print(error_color(f"\r[!] đã có lỗi khi nhận job, thử nhận lại"))
                waiting_ui(5, f"đã thử {count}/{maxcount} lần thử, đợi 5s...")
                err = True
            else:
                err = False
                break
            count += 1
        if err:
            print(error_color("[!] đã hết số lần thử!"))
            return {"error_not_import": r_get_jobs['error']}
        else:
            print(success_color("[*] đã nhận job thành công mà không có bất kỳ lỗi nào!"))
        
        # skip this job if job type is not follow
        if r_get_jobs[2].strip().lower() == "follow":
            # print the target and follow target
            print(purple_color(f"[#] mục tiêu -> {r_get_jobs[0]} (follow)"))
            follow_like_output = follow_instagram(current_account, r_get_jobs[0], r_get_jobs[3], cookies=cookies_inp, proxy=proxy)
            
            if 'following_status' in follow_like_output:
                if follow_like_output['following_status']:
                    print(success_color("[$] đã follow thành công!"))
                elif follow_like_output['outgoing_request']:
                    # lưu trữ account đã bị chặn vào file cục bộ để giảm tương tác
                    o = storage_block_account(current_account)
                    if "success" in o:
                        print(success_color(f"[*] {o['success']}"))
                    else:
                        print(error_color(f"[!] {o['error']}"))
                    print(purple_color("[#] đã follow nhưng cần chờ đối phương xác nhận"))

        elif r_get_jobs[2].strip().lower() == "like":
            # print the target and like target
            print(purple_color(f"[#] mục tiêu -> {r_get_jobs[0]} (like)"))
            follow_like_output = like_instagram(current_account, r_get_jobs[0], r_get_jobs[-1], cookies=cookies_inp, proxy=proxy)
            
            if 'is_final' in follow_like_output:
                if follow_like_output['is_final']:
                    print(success_color("[$] đã like thành công!"))

        else:
            print(error_color("[!] không phải nhiệm vụ follow và like"))
            drop_job_result = drop_job(r_get_jobs[1], r_get_jobs[3], instagram_golike_id_input, r_get_jobs[2])
            if "success" in drop_job_result:
                print(success_color(f"[*] {drop_job_result['success']}"))
            else:
                print(error_color(f"[!] {drop_job_result['error']}"))
                return drop_job_result
            waiting_ui(5, "-> vui lòng chờ đợi 5 giây")
            continue
        
        # if follow status is have in follow output will continue check
        if 'following_status' in follow_like_output:
            # if these both params is false, can inference this account temp blocking follow by instagram
            if not follow_like_output['following_status'] and not follow_like_output['outgoing_request']:
                drop_job_result = drop_job(r_get_jobs[1], r_get_jobs[3], instagram_golike_id_input, r_get_jobs[2])
                if "success" in drop_job_result:
                    print(success_color(f"[*] {drop_job_result['success']}"))
                else:
                    print(error_color(f"[!] {drop_job_result['error']}"))
                    return drop_job_result
                # lưu trữ account đã bị chặn vào file cục bộ để giảm tương tác
                o = storage_block_account(current_account)
                if "success" in o:
                    print(success_color(f"[*] {o['success']}"))
                else:
                    print(error_color(f"[!] {o['error']}"))
                return {"error": "account instagram này đã bị chặn like/follow, vui lòng đổi tài khoản mới"}
        # if follow status is have in follow output will continue check
        elif 'is_final' in follow_like_output:
            # if these both params is false, can inference this account temp blocking follow by instagram
            if not follow_like_output['is_final']:
                drop_job_result = drop_job(r_get_jobs[1], r_get_jobs[3], instagram_golike_id_input, r_get_jobs[2])
                if "success" in drop_job_result:
                    print(success_color(f"[*] {drop_job_result['success']}"))
                else:
                    print(error_color(f"[!] {drop_job_result['error']}"))
                    return drop_job_result
                # lưu trữ account đã bị chặn vào file cục bộ để giảm tương tác
                o = storage_block_account(current_account)
                if "success" in o:
                    print(success_color(f"[*] {o['success']}"))
                else:
                    print(error_color(f"[!] {o['error']}"))
                return {"error": "account instagram này đã bị chặn like/follow, vui lòng đổi tài khoản mới"}
        # skip job if target in job is not found
        elif "page_not_found" in follow_like_output:
            drop_job_result = drop_job(r_get_jobs[1], r_get_jobs[3], instagram_golike_id_input, r_get_jobs[2])
            if "success" in drop_job_result:
                print(success_color(f"[*] {drop_job_result['success']}"))
            else:
                print(error_color(f"[!] {drop_job_result['error']}"))
                return drop_job_result
            waiting_ui(wait_time, f"-> vui lòng chờ đợi {wait_time}s")
            do_desicion()
            continue
        # unknow error
        elif "error" in follow_like_output:
            drop_job_result = drop_job(r_get_jobs[1], r_get_jobs[3], instagram_golike_id_input, r_get_jobs[2])
            if "success" in drop_job_result:
                print(success_color(f"[*] {drop_job_result['success']}"))
            else:
                print(error_color(f"[!] {drop_job_result['error']}"))
                return drop_job_result
            return {"error": "account bị chặn hoặc lỗi không xác định"}
        
        # waiting 10s for verify job and get money
        waiting_ui(10, "-> vui lòng chờ đợi 10s để xác minh job")
        output = verify_complete_job(r_get_jobs[1], instagram_golike_id_input) # verify job
        # if error in verify job output, will skip this job and waiting for try again with new job
        if "error" in output:
            print(error_color(f"[!] {output['error']}"))
            drop_job_result = drop_job(r_get_jobs[1], r_get_jobs[3], instagram_golike_id_input, r_get_jobs[2])
            if "success" in drop_job_result:
                print(success_color(f"[*] {drop_job_result['success']}"))
            else:
                print(error_color(f"[!] {drop_job_result['error']}"))
                return drop_job_result
            waiting_ui(wait_time, f"vui lòng chờ đợi {wait_time}s")
            do_desicion()
            continue
        # else print output verify job status and continue do new jobs
        else:
            print(success_color(f"[$$] {output[1]}"))
            print(success_color(f"[$$] {output[2]}"))
            from __golRqs import total_price
            print(success_color(f"[$$] Tổng thu nhập của tất cả account -> {total_price}"))
            waiting_ui(wait_time, f"-> vui lòng chờ đợi {wait_time}s")
            do_desicion()
            continue
    else:
        print(success_color("[$] đã hết số lần tối đa trên mỗi account, sẽ đổi tài khoản và tiếp tục"))