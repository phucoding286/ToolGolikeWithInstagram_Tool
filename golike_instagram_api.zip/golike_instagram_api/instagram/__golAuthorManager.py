from modules import *

# storage golike author, token in local file for using later
def storage_golike_author(golike_author_path: str = "./golike_author.json"):
    # send the requests check account id but just get username golike for storage author data
    resj = None
    while True:
        try:
            response = scraper.get(
                url="https://gateway.golike.net/api/instagram-account",
                headers=GOLIKE_HEADERS
            )
            resj = response.json()
            break
        except:
            print(error_color("[!] đã có lỗi khi gửi yêu cầu check id, thử lại.."))
            continue

    # save golike author data in hist for using again then
    if not os.path.exists(golike_author_path):
        with open(golike_author_path, "w") as file:
            json.dump({}, file)
    with open(golike_author_path, "r") as file:
        author_data = json.load(file)
    if resj['data'][0]['username'] not in author_data:
        author_data[resj['data'][0]['username']] = {'authorization': GOLIKE_HEADERS['Authorization'], "token": GOLIKE_HEADERS['t']}
        with open(golike_author_path, "w") as file:
            json.dump(author_data, file)



# add author golike, token for run program
def golike_add_author_ui(golike_author_path: str = "./golike_author.json"):
    author_data = {}
    if os.path.exists(golike_author_path):
        with open(golike_author_path, "r") as file:
            author_data = json.load(file)
    
    choose = None
    golike_usernames = []
    if str(author_data) != "{}":
        print(system_color("[*] đã có sẵn tài khoản golike đã chạy lần trước ↓"))
        maxlen = max([len(key) for key in author_data.keys()]) + 25
        print(" -" + ((maxlen-2) * system_color("-")))
        count = 1
        for key, value in author_data.items():
            golike_usernames.append(key)
            key = f"| [{count}] username golike -> {key}"
            for _ in range(len(key), maxlen):
                key += " "
            key += "|"
            print(success_color(key))
            count += 1
        print(" -" + ((maxlen-2) * system_color("-")))
        print()
        
        while True:
            choose = input(system_color("[?] đã có account golike đã lưu, nhấp chọn hoặc gõ 'q' để thoát và thêm author mới\n-> "))
            if choose.strip().lower() == "q":
                break
            try:
                choose = int(choose) - 1
                break
            except:
                print(error_color("[!] vui lòng nhập đúng số thứ tự!"))

    if choose is None or isinstance(choose, str) and choose.strip().lower() == "q":
        # get golike authorization from user input
        golike_authorization_input = input(system_color("[?] nhập authorization golike của bạn\n-> "))
        GOLIKE_HEADERS['Authorization'] = golike_authorization_input
        # get golike token from user input
        golike_token_input = input(system_color("[?] nhập token golike của bạn\n-> "))
        GOLIKE_HEADERS['t'] = golike_token_input
    else:
        GOLIKE_HEADERS['Authorization'] = author_data[golike_usernames[choose]]['authorization']
        GOLIKE_HEADERS['t'] = author_data[golike_usernames[choose]]['token']