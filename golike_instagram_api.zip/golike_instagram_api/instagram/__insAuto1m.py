from modules import *

from __insAuto0m import auto0m
from __insLogin import login_instagram
from __randomDo import do_desicion, oneTimesRndDo
from __tempBlockDect import (
    check_and_freedom_for_blocked_account,
    storage_block_account
)

# auto switch account and wait if many errs
def auto1m(
        IDs,
        PASSWORDS,
        nicknames,
        wait_time,
        proxy_interaction,
        max_times_inp,
        waitime_when_error=1200,
        path_err="./account_error.txt",
        maxcount=5,
        sendtimes=5,
        fake_rqs_waitime=2,
        max_times_for_block_account=100
    ):
    
    # loop activing forever
    sum_login_error = 0
    sum_activate_error = 0
    while True:
        # loop for check and run job on list account linking on golike
        for i in range(len(IDs)):
            
            # chọn ngẫu nhiên dùng hoặc bỏ qua account
            # if oneTimesRndDo():
            #     print(success_color(f"[*] Máy đã chọn '{nicknames[i]}' để tương tác"))
            # else:
            #     print(purple_color(f"[!] Máy chọn bỏ qua '{nicknames[i]}'"))
            #     waiting_ui((sendtimes*fake_rqs_waitime)+wait_time, f"-> vui lòng chờ đợi {(sendtimes*fake_rqs_waitime)+wait_time}s")
            #     do_desicion()
            #     continue

            cookies = None
            # try login and get sessions with password saved
            login_error = False
            for passwd in PASSWORDS:
                login_output = login_instagram(nicknames[i], passwd, proxy_interaction)
                if "error" in login_output:
                    sum_login_error += 1
                    print(error_color(f"[!] {login_output['error']}"))
                    waiting_ui(timeout=5, text="-> đợi 5s để tiếp tục")
                    login_error = True
                    continue
                else:
                    sum_login_error = 0
                    print(success_color(f"[*] {login_output['success']}"))
                    cookies = login_output['cookies']
                    login_error = False
                    break
            # save error account into log
            if login_error:
                with open(path_err, "a") as file:
                    file.write(f"{nicknames[i]}\n")
            # if cookies is None can inference is this account is blocked or failed login for get cookies
            # so let's skip this account
            if cookies is None:
                if sum_login_error >= (len(IDs)-2) * len(PASSWORDS):
                    waiting_ui(timeout=waitime_when_error, text=f"-> vui lòng đợi {waitime_when_error}s để check lại và chạy follow cho tất cả tài khoản")
                    do_desicion()
                    sum_login_error = 0
                else:
                    sum_login_error += 1
                    waiting_ui(5, "-> đợi 5s để tiếp tục")
                continue
            # else (if cookies if not none) will run golike automation follow instagram and get money
            else:
                proxy_interaction = login_output['proxy'] if proxy_interaction else None
                golike_auto_output = auto0m(IDs[i], cookies, wait_time, nicknames[i], proxy_interaction, max_times_inp, maxcount=maxcount, sendtimes=sendtimes, fake_rqs_waitime=fake_rqs_waitime)

                if golike_auto_output is None:
                    sum_activate_error = 0
                    continue

                elif "error" in golike_auto_output:
                    sum_activate_error += 1
                    print(error_color(f"[!] {golike_auto_output['error']}"))

                elif "error_not_import" in golike_auto_output:
                    print(error_color(f"[!] {golike_auto_output['error_not_import']}"))
                    sum_activate_error += 1

                if sum_activate_error > len(IDs) - 2:
                    waiting_ui(timeout=waitime_when_error, text=f"-> vui lòng đợi {waitime_when_error}s để check lại và chạy follow cho tất cả tài khoản")
                    do_desicion()
                    sum_activate_error = 0
                    continue