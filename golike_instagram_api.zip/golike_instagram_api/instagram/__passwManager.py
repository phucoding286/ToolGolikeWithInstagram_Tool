from modules import *

# add more password for instagram
def add_passwords_ui():
    while True:
        try:
            print(purple_color("[!] nhập lệnh exit nếu bạn muốn thoát khỏi!"))
            passwd_inp = input(system_color("[?] nhập password chung bạn muốn thêm\n-> "))
            
            # exit the terminal for add passwords
            if passwd_inp.lower().strip() == "exit":
                print(system_color("[*] bạn đã thoát khỏi trình thêm passwords!"))
                print()
                break
            
            # add new password in file
            if os.path.exists("./password.json"):
                passwords = json.load(open("./password.json", "r"))
                passwords['passwords'].append(passwd_inp)
            else:
                passwords = {"passwords": [passwd_inp]}
            json.dump(passwords, open("./password.json", 'w'))
            print(success_color(f"[*] đã thêm password -> '{passwd_inp}' thành công!"))
            print()
        except Exception as e:
            print(error_color(f"[!] đã có lỗi khi thêm password -> '{passwd_inp}'!"))




def print_passwords_table(screen_wait=False):
    passwords = json.load(open("./password.json", "r"))
    passwords = passwords['passwords']

    if str(passwords) == "[]":
        input(system_color("[!] không có passwords chung nào hiện có! enter để quay lại console chính\n-> "))
        return 0 
                
    maxlen = max([len(passwords[i]) for i in range(len(passwords))]) + 15

    print(system_color("[*] danh sách các passwords chung hiện có bên dưới ↓"))
    print(system_color(" -" + ((maxlen-1) * "-") ))
    for i in range(len(passwords)):
        password = f"| [{i+1}] -> {passwords[i]}"
        for _ in range(len(password), maxlen):
            password += " "
        password += '|'
        print(system_color(password))
    print(system_color(" -" + ((maxlen-1) * "-") ))

    if screen_wait:
        print()
        input(system_color("[#] nhấn enter để quay lại\n-> "))
        



def delete_passwords_ui():
    if os.path.exists("./password.json"):
        passwords = json.load(open("./password.json", "r"))
        if str(passwords['passwords']) != "[]":
            passwords = passwords['passwords']

            print_passwords_table()

            print()
            while True:
                choose_password_delete = input(system_color("[?] nhập password bạn muốn xóa hoặc gõ 'clear' để xóa tất cả\n-> "))

                if choose_password_delete.strip().lower() == "clear":
                    json.dump({"passwords": []}, open("./password.json", "w"))
                    input(system_color("[!] không có passwords chung nào hiện có! enter để quay lại console chính\n-> "))
                    return 0 
                try:
                    choose_password_delete = int(choose_password_delete)
                except:
                    print(error_color("[!] vui lòng nhập số thứ tự tương ứng!"))
                    print()

                passwd_hist = passwords[choose_password_delete-1]
                try:
                    passwords.pop(choose_password_delete-1)
                    json.dump({"passwords": passwords}, open("./password.json", "w"))
                    print(success_color(f"[*] đã xóa passwords -> {passwd_hist} thành công!"))
                    print()
                    print_passwords_table()
                except Exception as e:
                    print(error_color(f"[!] xóa passwords -> {passwd_hist} không thành công!"))
                    print()
                    print_passwords_table()
        else:
            input(system_color("[!] không có passwords chung nào hiện có! enter để quay lại console chính\n-> "))




def add_username_password_instagram(path="./instgaram_cookies.json"):
    with open(path, "r") as file:
        instagram_cookies = json.load(file)
    while True:
        print(purple_color("[*] bạn có thể nhập 'exit' để thoát"))
        username = input(system_color("[?] nhập vào username bạn cần truy vấn\n-> "))
        if username.strip().lower() == "exit":
            print(success_color("[*] bạn đã chọn thoát chương trình này"))
            return 0
        if username not in instagram_cookies:
            choose = input(success_color(f"[!] username {username} chưa tồn tại trong database, muốn thêm? (Y/n)\n-> "))
            if choose.strip().lower() == "y":
                print(system_color(f"[*] bạn đã lựa chọn thêm username -> {username}"))
                password = input(system_color(f"[?] nhập password cho username -> {username}\n[{username}]> "))
                cookies = input(system_color(f"[?] nhập cookies cho username (enter mặc định trống)\n[{username}]> "))
                instagram_cookies[username] = {"username": username, "password": password, "cookie": cookies, "proxy": None}
                try:
                    with open(path, "w") as file:
                        json.dump(instagram_cookies, file)
                    print(success_color(f"[*] đã lưu thông tin cho username {username} thành công"))
                    print()
                except:
                    print(error_color(f"[*] bị lỗi khi lưu thông tin cho username {username}!"))
                    print()
            else:
                print()
                continue
        else:
            if "username" not in instagram_cookies[username] or "password" not in instagram_cookies[username]:
                choose = input(system_color(f"[!] username {username} đã tồn tại trong database nhưng chưa có thông tin, muốn thêm? (Y/n)\n-> "))
                if choose.strip().lower() == "y":
                    password = input(system_color(f"[?] nhập password cho username -> {username}\n[{username}]> "))
                    cookies = input(system_color(f"[?] nhập cookies cho username (enter mặc định trống)\n[{username}]> "))
                    info = {"username": username, "password": password}
                    if "cookie" in instagram_cookies[username]:
                        info["cookie"] = instagram_cookies[username]['cookie']
                    else:
                        info["cookie"] = cookies
                    if "proxy" in instagram_cookies[username]:
                        info["proxy"] = instagram_cookies[username]['proxy']
                    else:
                        info['proxy'] = None
                    instagram_cookies[username] = info    
                    try:
                        with open(path, "w") as file:
                            json.dump(instagram_cookies, file)
                        print(success_color(f"[*] đã lưu thông tin cho username {username} thành công"))
                        print()
                    except:
                        print(error_color(f"[*] bị lỗi khi lưu thông tin cho username {username}!"))
                        print()
                else:
                    print()
                    continue
            else:
                print(success_color(f"[*] thông tin của {username} đã tồn tại rồi!"))
                choose = input(system_color("[?] bạn muốn chỉnh sửa mật khẩu?(Y/n)\n-> "))
                if choose.strip().lower() == "y":
                    while True:
                        print()
                        print(purple_color("[!] lưu ý! bạn có thể gõ 'exit' để thoát khỏi terminal"))
                        print(success_color(" -> gõ lệnh 'ls password' để xem các password hiện có"))
                        print(success_color(" -> gõ lệnh 'change' để đổi mật khẩu, ví dụ 'change abc123'"))
                        print()
                        terminal_input = input(system_color(f"[{username}]> "))
                        if terminal_input.lower().split()[0] == 'change':
                            try:
                                password = terminal_input.split()[1]
                            except:
                                print(error_color("[!] vui lòng nhập tham số khi đổi mật khẩu"))
                                continue
                            instagram_cookies[username]['password'] = password
                            try:
                                with open(path, "w") as file:
                                    json.dump(instagram_cookies, file)
                                print(success_color(f"[*] đã lưu mật khẩu '{password}' cho '{username}' thành công!"))
                            except:
                                print(error_color(f"[!] lưu mật khẩu '{password}' cho '{username}' thất bại!"))
                            print()
                            input(system_color("[*] enter để tiếp tục\n-> "))
                            print()
                        elif terminal_input.lower().strip() == "ls password":
                            print(purple_color(f"[#] password của account {username} -> {instagram_cookies[username]['password']}"))
                            print()
                            input(system_color("[*] enter để tiếp tục\n-> "))
                            print()
                        elif terminal_input.lower().strip() == "exit":
                            break
                continue