from modules import *
from __golAuthorManager import (
    golike_add_author_ui,
    storage_golike_author
)
from __getGolInsUsername import get_golike_instagram_usernames
from __insAuto1m import auto1m

# golike instagram UI
def auto2m(golike_author_path: str = "./golike_author.json"):
    global GOLIKE_HEADERS
    PASSWORDS = json.load(open("./password.json"))
    PASSWORDS = PASSWORDS['passwords']

    # golike author read and write
    golike_add_author_ui(golike_author_path)
    storage_golike_author(golike_author_path)
    IDs, nicknames = get_golike_instagram_usernames()
    print()
    
    # get waitime for next job from user input
    wait_time = int(input(system_color("[?] nhập số thời gian chờ trước khi follow tiếp theo\n-> ")))
    # max times for interaction on account
    max_times_inp = int(input(system_color("[?] nhập vào số lần tối đa mà một account có thể tương tác\n-> ")))
    # wait time when error too much
    waitime_when_error = int(input(system_color("[?] nhập vào số thời gian chờ tối đa khi bị lỗi quá nhiều\n-> ")))
    maxcount = int(input(system_color("[?] số lần tối đa để thử lại nhận job\n-> ")))
    sendtimes = int(input(system_color("[?] nhập số lần gửi các yêu cầu mô phỏng\n-> ")))
    fake_rqs_waitime = int(input(system_color("[?] nhập vào thời gian chờ cho lần gửi rqs mô phỏng tiếp theo\n-> ")))
    # ask about using proxy in activing progress or not
    proxy_choose_interaction = input(system_color("[?] bạn có muốn dùng proxy trong quá trình tương tác instagram không?(Y/n)\n-> "))
    print()
    
    if proxy_choose_interaction.strip().lower() == "y":
        print(success_color("[!] bạn đã lựa chọn là sử dụng proxy trong quá trình tương tác"))
        proxy_interaction = True
    else:
        print(error_color("[1] bạn đã lựa chọn là không sử dụng proxy trong quá trình tương tác"))
        proxy_interaction = None
    
    print(system_color("[!] bạn có thể dùng CTRL+C để thoát khỏi chương trình và quay về console"))
    waiting_ui(2, "-> đợi 2 giây để chạy tool")
    
    # run golike auto and auto switch accounts
    print()
    print()
    try:
        auto1m(IDs, PASSWORDS, nicknames, wait_time, proxy_interaction, max_times_inp, waitime_when_error=waitime_when_error, maxcount=maxcount, sendtimes=sendtimes, fake_rqs_waitime=fake_rqs_waitime)
    except KeyboardInterrupt:
        print(success_color("[#] đã nhận CTRL+C, quay lại..."))