from modules import *

import __oneAccMode as oneAccMode
import __manuallyInsLogin as manuallyInsLogin
from __insAuto2m import auto2m

from __passwManager import (
    add_passwords_ui,
    delete_passwords_ui,
    print_passwords_table,
    add_username_password_instagram
)


# main program
if __name__ == "__main__":
    while True:
        
        if not os.path.exists("./password.json"):
            choose = input(system_color("[?] file 'password.json' chưa có, bạn muốn tạo? (Y/n)\n-> "))
            if choose.strip().lower() == "y":
                print(purple_color("[!] tạo file 'password.json' ..."))
                with open("password.json", "w") as file:
                    json.dump({"passwords": []}, open("./password.json", "w"))
                    print(success_color("[@] tạo file 'password.json' thành công"))
            else:
                exit()
                
        print(system_color(" --------------------------------------------"))
        print((system_color("|")+success_color(" TOOL GOLIKE INSTAGRAM AUTO 100% BY PHUTECH ")+system_color("|")))
        print(system_color("| facebook -> Programing Sama                |"))
        print(system_color("| youtube -> Phu Tech                        |"))
        print(system_color("| github -> @phucoding286                    |"))
        print(system_color(" --------------------------------------------"))
        print(system_color("| [1] chạy tool golike tự động cho instagram |"))
        print(system_color("| [2] thêm các passwords chung cho instagram |"))
        print(system_color("| [3] xóa các passwords chung của instagram  |"))
        print(system_color("| [4] xem các passwords chung hiện đang lưu  |"))
        print(system_color("| [5] thêm thông tin instagram vào database  |"))
        print(system_color("| [6] chế độ một tài khoản                   |"))
        print(system_color("| [7] đăng nhập và lấy cookie instagram      |"))
        print(system_color(" --------------------------------------------"))
        print()
        print(system_color("[!] các chức năng chính ↓"))
        print(success_color(" -> tự động đăng nhập và tương tác instagram"))
        print(success_color(" -> tự động nhận job và xác minh job golike"))
        print(success_color(" -> tự động chờ khi có quá nhiều lần chặn hoặc lỗi"))
        print(success_color(" -> tự động giả mạo các thông tin để giảm thiểu nghi ngờ"))
        print()

        choose_inp = input(system_color("[|] nhập lựa chọn của bạn\n-> "))
        print()

        if choose_inp.strip().lower() == "1":
            auto2m()
            print()
        elif choose_inp.strip().lower() == "2":
            add_passwords_ui()
            print()
        elif choose_inp.strip().lower() == "3":
            delete_passwords_ui()
            print()
        elif choose_inp.strip().lower() == "4":
            print_passwords_table(True)
            print()
        elif choose_inp.strip().lower() == "5":
            add_username_password_instagram()
            print()
        elif choose_inp.strip().lower() == "6":
            oneAccMode.main()
            print()
        elif choose_inp.strip().lower() == "7":
            manuallyInsLogin.lg_get_ck()
            
        else:
            print(error_color("[!] vui lòng nhập đúng số thứ tự"))
            print()
            time.sleep(1)